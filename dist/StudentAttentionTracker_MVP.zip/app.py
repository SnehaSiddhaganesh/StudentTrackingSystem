"""
AI-Based Classroom Attention Monitoring System - Main Streamlit Dashboard
Submission for RB Tech Services Internship MVP
"""
import os
import sys
import time
import uuid
import cv2
import numpy as np
import pandas as pd
import streamlit as st
try:
    import plotly.express as px
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False
from datetime import datetime

# Add root directory to sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from attention_engine import (
    FaceDetector, HeadPoseEstimator, GazeEstimator,
    DrowsinessDetector, StudentTracker, AttentionClassifier
)
from database import DatabaseManager
from training.train_model import train_xgboost_model
from utils.sample_generator import generate_sample_video
from utils.report_generator import generate_pdf_report
from utils.packager import create_project_zip

# Streamlit Page Setup
st.set_page_config(
    page_title="AI Classroom Attention Monitor",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load Custom Glassmorphism CSS
def load_css():
    css_path = os.path.join(BASE_DIR, 'assets', 'style.css')
    if os.path.exists(css_path):
        with open(css_path, 'r', encoding='utf-8') as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css()

# Ensure Model & Sample Video exist on startup
@st.cache_resource
def initialize_system_resources():
    model_path = os.path.join(BASE_DIR, 'models', 'xgboost_attention.pkl')
    if not os.path.exists(model_path):
        with st.spinner("Initializing AI Models..."):
            train_xgboost_model(model_path)
            
    video_path = os.path.join(BASE_DIR, 'assets', 'sample_classroom.mp4')
    if not os.path.exists(video_path):
        with st.spinner("Generating Demo Classroom Stream Video..."):
            generate_sample_video(video_path)

initialize_system_resources()

# Initialize Database Manager
db_manager = DatabaseManager()

# Session State Initialization
if 'session_id' not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())[:8]
if 'is_running' not in st.session_state:
    st.session_state.is_running = False
if 'attention_history' not in st.session_state:
    st.session_state.attention_history = []
if 'alerts_list' not in st.session_state:
    st.session_state.alerts_list = []

# Sidebar Controls
st.sidebar.markdown("## 🎓 System Controls")
st.sidebar.markdown("---")

input_mode = st.sidebar.selectbox(
    "📹 Video Source",
    ["🎥 Demo Classroom Video", "📹 Upload Video File", "📷 Live Webcam Feed"],
    index=0
)

uploaded_file = None
webcam_id = 0

if input_mode == "📹 Upload Video File":
    uploaded_file = st.sidebar.file_uploader("Upload Classroom Video (MP4/AVI)", type=["mp4", "avi", "mov"])
elif input_mode == "📷 Live Webcam Feed":
    webcam_id = st.sidebar.number_input("Webcam Device Index", min_value=0, max_value=5, value=0)

st.sidebar.markdown("---")
st.sidebar.markdown("### ⚙️ Detection Thresholds")

attention_threshold = st.sidebar.slider("Min Attention Score (%)", 40, 90, 65)
ear_threshold = st.sidebar.slider("Drowsiness EAR Threshold", 0.15, 0.30, 0.21, step=0.01)
sustained_seconds = st.sidebar.slider("Alert Sustained Time (Sec)", 2, 10, 4)

st.sidebar.markdown("---")
st.sidebar.markdown("### 🔒 Privacy & DPDP Compliance")

blur_faces = st.sidebar.checkbox("Blur Student Faces (Anonymization)", value=False)
mask_student_ids = st.sidebar.checkbox("Mask Student Identifiers", value=False)

st.sidebar.markdown("---")

col_start, col_stop = st.sidebar.columns(2)
with col_start:
    if st.button("▶️ Start", use_container_width=True):
        st.session_state.is_running = True
        st.session_state.session_id = str(uuid.uuid4())[:8]
        st.session_state.attention_history = []
        st.session_state.alerts_list = []
        db_manager.create_session(st.session_state.session_id)
        st.rerun()

with col_stop:
    if st.button("⏹️ Stop", use_container_width=True):
        st.session_state.is_running = False
        db_manager.end_session(st.session_state.session_id)
        st.rerun()

st.sidebar.markdown("---")
if st.sidebar.button("📦 Package Submission ZIP", use_container_width=True):
    zip_path = create_project_zip()
    with open(zip_path, "rb") as fp:
        st.sidebar.download_button(
            label="💾 Download Project ZIP",
            data=fp,
            file_name="StudentAttentionTracker_MVP.zip",
            mime="application/zip",
            use_container_width=True
        )

# Main App Header
st.markdown(f"""
    <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;'>
        <div>
            <h1 style='margin:0; padding:0;'>AI-Based Classroom Attention Monitoring System</h1>
            <p style='color: #94a3b8; margin-top: 0.2rem;'>Real-time computer vision & ML engagement analytics dashboard</p>
        </div>
        <div>
            <span class='badge {"badge-attentive" if st.session_state.is_running else "badge-distracted"}'>
                {"● LIVE MONITORING ACTIVE" if st.session_state.is_running else "SESSION IDLE"}
            </span>
        </div>
    </div>
""", unsafe_allow_html=True)

# Dashboard Top Stats Grid
metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)

with metric_col1:
    st.markdown("""
        <div class='metric-card'>
            <div class='metric-label'>Class Avg Attention</div>
            <div class='metric-value' style='color: #38bdf8;' id='metric-attention'>-- %</div>
            <div class='metric-delta' style='color: #34d399;'>Target: >= 65%</div>
        </div>
    """, unsafe_allow_html=True)

with metric_col2:
    st.markdown("""
        <div class='metric-card'>
            <div class='metric-label'>Attentive Students</div>
            <div class='metric-value' style='color: #34d399;' id='metric-attentive'>--</div>
            <div class='metric-delta' style='color: #94a3b8;'>Focusing on content</div>
        </div>
    """, unsafe_allow_html=True)

with metric_col3:
    st.markdown("""
        <div class='metric-card'>
            <div class='metric-label'>Distracted Students</div>
            <div class='metric-value' style='color: #fbbf24;' id='metric-distracted'>--</div>
            <div class='metric-delta' style='color: #94a3b8;'>Looking away / Side pose</div>
        </div>
    """, unsafe_allow_html=True)

with metric_col4:
    st.markdown("""
        <div class='metric-card'>
            <div class='metric-label'>Drowsy / Fatigue</div>
            <div class='metric-value' style='color: #f87171;' id='metric-drowsy'>--</div>
            <div class='metric-delta' style='color: #94a3b8;'>Eye closure / Yawning</div>
        </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Main Analytics Section (Video Canvas + Realtime Trend Chart)
canvas_col, chart_col = st.columns([1.5, 1])

with canvas_col:
    st.markdown("### 📹 Live Video Stream & Detection Canvas")
    video_placeholder = st.empty()

with chart_col:
    st.markdown("### 📈 Live Class Engagement Trend")
    chart_placeholder = st.empty()

st.markdown("---")

# Per-Student Gauges Grid & Low Attention Alerts Panel
student_col, alert_col = st.columns([1.2, 1])

with student_col:
    st.markdown("### 👥 Per-Student Real-Time Focus Metrics")
    student_cards_placeholder = st.empty()

with alert_col:
    st.markdown("### 🚨 Sustained Low-Attention & Fatigue Alerts")
    alerts_placeholder = st.empty()

st.markdown("---")

# Historical Session Report & PDF Exporter
st.markdown("### 📄 Session Report & Analytics Export")
report_col1, report_col2 = st.columns([2, 1])

with report_col1:
    sessions_df = db_manager.get_all_sessions()
    if not sessions_df.empty:
        st.dataframe(sessions_df, use_container_width=True, height=180)
    else:
        st.info("No recorded sessions in database yet. Click '▶️ Start' to record a session.")

with report_col2:
    if st.button("📊 Export Session PDF Report", use_container_width=True):
        sess_df = db_manager.get_session_logs_df(st.session_state.session_id)
        al_df = db_manager.get_session_alerts_df(st.session_state.session_id)
        pdf_path = generate_pdf_report(st.session_state.session_id, sess_df, al_df)
        
        if os.path.exists(pdf_path):
            with open(pdf_path, "rb") as f:
                st.download_button(
                    label="📥 Download PDF Engagement Report",
                    data=f,
                    file_name=f"Attention_Report_{st.session_state.session_id}.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )

# --- Video Processing Loop ---
if st.session_state.is_running:
    # Initialize Engine Components
    detector = FaceDetector(max_num_faces=10)
    head_pose_est = HeadPoseEstimator()
    gaze_est = GazeEstimator()
    drowsiness_det = DrowsinessDetector(ear_threshold=ear_threshold)
    student_tracker = StudentTracker()
    classifier = AttentionClassifier()

    # Determine Video Source
    cap = None
    if input_mode == "🎥 Demo Classroom Video":
        sample_path = os.path.join(BASE_DIR, 'assets', 'sample_classroom.mp4')
        cap = cv2.VideoCapture(sample_path)
    elif input_mode == "📹 Upload Video File" and uploaded_file is not None:
        tfile = f"temp_upload_{st.session_state.session_id}.mp4"
        with open(tfile, "wb") as f:
            f.write(uploaded_file.read())
        cap = cv2.VideoCapture(tfile)
    elif input_mode == "📷 Live Webcam Feed":
        cap = cv2.VideoCapture(webcam_id)

    if cap is None or not cap.isOpened():
        st.error("Unable to open video source. Please check webcam or video file.")
        st.session_state.is_running = False
    else:
        fps_counter = 0
        start_time = time.time()

        while st.session_state.is_running and cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                # Loop demo video
                if input_mode == "🎥 Demo Classroom Video":
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                else:
                    break

            fps_counter += 1
            h, w = frame.shape[:2]

            # 1. Detect faces & landmarks
            detections = detector.process(frame)
            
            raw_attention_results = []
            frame_logs = []

            for det in detections:
                lm_px = det['landmarks_px']

                # 2. Extract visual cues
                head_pose = head_pose_est.estimate_pose(lm_px, frame.shape)
                gaze = gaze_est.estimate_gaze(lm_px, head_pose, frame.shape)
                drowsiness = drowsiness_det.process(lm_px)

                # 3. Classify attention
                att_res = classifier.classify(head_pose, gaze, drowsiness)
                raw_attention_results.append(att_res)
                
                frame_logs.append({
                    'head_pose': head_pose,
                    'gaze': gaze,
                    'drowsiness': drowsiness,
                    'att_res': att_res
                })

            # 4. Multi-student persistent tracking & EMA smoothing
            tracked_students = student_tracker.update(detections, raw_attention_results)

            # Compute Class Summary Metrics
            attentive_count = 0
            distracted_count = 0
            drowsy_count = 0
            total_class_score = 0.0

            for i, student in enumerate(tracked_students):
                sid = student['student_id']
                bx, by, bw, bh = student['bbox']
                smoothed_score = student['smoothed_attention']
                
                # Fetch corresponding frame log metrics
                log_data = frame_logs[i] if i < len(frame_logs) else None
                status = log_data['att_res']['status'] if log_data else ('Attentive' if smoothed_score >= 65 else 'Distracted')

                if status == 'Attentive':
                    attentive_count += 1
                elif status == 'Distracted':
                    distracted_count += 1
                elif status == 'Drowsy':
                    drowsy_count += 1

                total_class_score += smoothed_score

                # Handle Privacy Anonymization
                if blur_faces:
                    face_roi = frame[by:by+bh, bx:bx+bw]
                    if face_roi.size > 0:
                        blurred_roi = cv2.GaussianBlur(face_roi, (51, 51), 30)
                        frame[by:by+bh, bx:bx+bw] = blurred_roi

                # Draw Visual Overlay Bounding Boxes & Tags
                color = (50, 205, 50) if status == 'Attentive' else ((0, 215, 255) if status == 'Distracted' else (50, 50, 255))
                cv2.rectangle(frame, (bx, by), (bx + bw, by + bh), color, 2)

                # Head Pose Nose Direction Arrow
                if log_data and 'nose_start' in log_data['head_pose']:
                    p1 = log_data['head_pose']['nose_start']
                    p2 = log_data['head_pose']['nose_end']
                    cv2.arrowedLine(frame, p1, p2, (255, 255, 0), 2, tipLength=0.3)

                # Label Card above BBox
                disp_id = f"Student #{sid}" if not mask_student_ids else f"Student #{sid * 7 % 99}"
                label_str = f"{disp_id} | {status} ({smoothed_score:.0f}%)"
                cv2.rectangle(frame, (bx, by - 28), (bx + len(label_str) * 9, by), color, -1)
                cv2.putText(frame, label_str, (bx + 5, by - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

                # Database Logging per frame
                if log_data:
                    db_manager.log_student_attention(
                        st.session_state.session_id, sid, smoothed_score, status,
                        log_data['head_pose']['yaw'], log_data['head_pose']['pitch'],
                        log_data['drowsiness']['avg_ear'], log_data['gaze']['gaze_score']
                    )

                # Sustained Alert Check
                if student['sustained_low_count'] > (sustained_seconds * 15):
                    alert_msg = f"Sustained {status} state for student #{sid} (> {sustained_seconds}s)"
                    db_manager.log_alert(st.session_state.session_id, sid, status, alert_msg)
                    if not any(a['sid'] == sid and a['status'] == status for a in st.session_state.alerts_list[-5:]):
                        st.session_state.alerts_list.append({
                            'time': datetime.now().strftime('%H:%M:%S'),
                            'sid': sid,
                            'status': status,
                            'msg': alert_msg
                        })

            # Calculate Class Average Attention Score
            num_students = max(1, len(tracked_students))
            class_avg_attention = total_class_score / num_students if len(tracked_students) > 0 else 0.0

            # Store timeline metric
            st.session_state.attention_history.append({
                'time': datetime.now().strftime('%H:%M:%S'),
                'attention': class_avg_attention,
                'attentive': attentive_count,
                'distracted': distracted_count,
                'drowsy': drowsy_count
            })

            # Limit history buffer to last 60 seconds
            if len(st.session_state.attention_history) > 60:
                st.session_state.attention_history.pop(0)

            # --- Render Streamlit UI Components ---
            # 1. Update Video Canvas Frame
            rgb_canvas = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            video_placeholder.image(rgb_canvas, channels="RGB", use_container_width=True)

            # 2. Update Realtime Trendline Chart
            df_hist = pd.DataFrame(st.session_state.attention_history)
            if not df_hist.empty:
                if HAS_PLOTLY:
                    fig = go.Figure()
                    fig.add_trace(go.Scatter(
                        x=df_hist['time'], y=df_hist['attention'],
                        mode='lines+markers', name='Class Attention %',
                        line=dict(color='#38bdf8', width=3),
                        fill='tozeroy', fillcolor='rgba(56, 189, 248, 0.1)'
                    ))
                    fig.add_hline(y=attention_threshold, line_dash="dash", line_color="#fbbf24", annotation_text="Min Target")
                    fig.update_layout(
                        paper_bgcolor='rgba(0,0,0,0)',
                        plot_bgcolor='rgba(15, 23, 42, 0.5)',
                        font=dict(color='#94a3b8'),
                        margin=dict(l=20, r=20, t=30, b=20),
                        height=300,
                        yaxis=dict(range=[0, 100], title="Attention %")
                    )
                    chart_placeholder.plotly_chart(fig, use_container_width=True, key=f"chart_{fps_counter}")
                else:
                    chart_df = df_hist[['time', 'attention']].set_index('time')
                    chart_placeholder.line_chart(chart_df, height=280)

            # 3. Render Per-Student Focus Cards
            student_cards_html = "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;'>"
            for student in tracked_students:
                sid = student['student_id']
                score = student['smoothed_attention']
                badge_cls = 'badge-attentive' if score >= 65 else ('badge-distracted' if score >= 40 else 'badge-drowsy')
                student_cards_html += f"""
                    <div class='glass-panel' style='padding: 1rem; margin:0;'>
                        <div style='display:flex; justify-between; align-items:center;'>
                            <strong style='color:#f8fafc;'>Student #{sid}</strong>
                            <span class='badge {badge_cls}'>{score:.0f}%</span>
                        </div>
                        <div style='background:rgba(255,255,255,0.1); border-radius:10px; height:8px; margin-top:0.75rem; overflow:hidden;'>
                            <div style='background: linear-gradient(90deg, #38bdf8, #34d399); width:{score}%; height:100%;'></div>
                        </div>
                    </div>
                """
            student_cards_html += "</div>"
            student_cards_placeholder.markdown(student_cards_html, unsafe_allow_html=True)

            # 4. Render Low Attention Alerts Log
            if st.session_state.alerts_list:
                alerts_html = ""
                for alert in list(reversed(st.session_state.alerts_list))[:4]:
                    alerts_html += f"""
                        <div class='alert-card'>
                            <div class='alert-title'>⚠️ [{alert['time']}] Alert: Student #{alert['sid']} ({alert['status']})</div>
                            <div class='alert-sub'>{alert['msg']}</div>
                        </div>
                    """
                alerts_placeholder.markdown(alerts_html, unsafe_allow_html=True)
            else:
                alerts_placeholder.info("No sustained low-attention alerts triggered.")

            time.sleep(0.03) # Cap at ~30 FPS

        cap.release()

# Footer
st.markdown("---")
st.markdown("<p style='text-align: center; color: #64748B; font-size: 0.85rem;'>AI-Based Classroom Attention Monitoring System | Developed for RB Tech Services Internship MVP</p>", unsafe_allow_html=True)
