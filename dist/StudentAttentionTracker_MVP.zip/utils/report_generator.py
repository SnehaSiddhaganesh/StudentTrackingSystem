"""
Report Generator creating exportable PDF and HTML Classroom Engagement Reports.
"""
import os
import pandas as pd
from datetime import datetime

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False

def generate_pdf_report(session_id, session_df, alerts_df, output_path=None):
    """
    Generates a PDF session engagement report.
    Returns path to generated PDF or HTML file.
    """
    if output_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_path = os.path.join(base_dir, 'assets', f'Session_Report_{session_id}.pdf')

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    if not HAS_REPORTLAB:
        # Fallback to HTML report generation if reportlab is not installed
        html_path = output_path.replace('.pdf', '.html')
        return generate_html_report(session_id, session_df, alerts_df, html_path)

    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40
    )
    
    styles = getSampleStyleSheet()
    
    # Custom Palette
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=22,
        textColor=colors.HexColor('#0F172A'),
        spaceAfter=10
    )
    
    subtitle_style = ParagraphStyle(
        'SubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        textColor=colors.HexColor('#64748B'),
        spaceAfter=15
    )

    heading2 = ParagraphStyle(
        'H2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=14,
        textColor=colors.HexColor('#1E293B'),
        spaceBefore=12,
        spaceAfter=8
    )

    normal_text = ParagraphStyle(
        'NormalText',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        textColor=colors.HexColor('#334155'),
        leading=14
    )

    story = []

    # Title & Header
    story.append(Paragraph("Classroom Attention Analytics Report", title_style))
    story.append(Paragraph(f"Session ID: <b>{session_id}</b> | Generated on: <b>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</b>", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#38BDF8'), spaceAfter=15))

    # Executive Summary Metrics
    avg_attention = session_df['attention_score'].mean() if not session_df.empty else 0.0
    total_logs = len(session_df)
    total_students = session_df['student_id'].nunique() if not session_df.empty else 0
    total_alerts = len(alerts_df)

    attentive_cnt = len(session_df[session_df['status'] == 'Attentive']) if not session_df.empty else 0
    distracted_cnt = len(session_df[session_df['status'] == 'Distracted']) if not session_df.empty else 0
    drowsy_cnt = len(session_df[session_df['status'] == 'Drowsy']) if not session_df.empty else 0

    summary_data = [
        ['Metric', 'Value'],
        ['Overall Class Attention Avg', f"{avg_attention:.1f}%"],
        ['Unique Students Detected', str(total_students)],
        ['Attentive Sample Count', f"{attentive_cnt} ({(attentive_cnt/max(1,total_logs)*100):.1f}%)"],
        ['Distracted Sample Count', f"{distracted_cnt} ({(distracted_cnt/max(1,total_logs)*100):.1f}%)"],
        ['Drowsy Sample Count', f"{drowsy_cnt} ({(drowsy_cnt/max(1,total_logs)*100):.1f}%)"],
        ['Sustained Low-Attention Alerts', str(total_alerts)]
    ]

    t_summary = Table(summary_data, colWidths=[250, 250])
    t_summary.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (1, 0), colors.HexColor('#0F172A')),
        ('TEXTCOLOR', (0, 0), (1, 0), colors.white),
        ('FONTNAME', (0, 0), (1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (1, 0), 8),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F8FAFC')),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    
    story.append(Paragraph("Executive Summary", heading2))
    story.append(t_summary)
    story.append(Spacer(1, 15))

    # Per-Student Breakdown Table
    story.append(Paragraph("Per-Student Engagement Breakdown", heading2))
    if not session_df.empty:
        student_stats = session_df.groupby('student_id').agg(
            avg_score=('attention_score', 'mean'),
            most_freq_status=('status', lambda x: x.mode()[0] if not x.empty else 'N/A')
        ).reset_index()

        stu_data = [['Student ID', 'Average Attention', 'Dominant State', 'Intervention Recommendation']]
        for _, row in student_stats.iterrows():
            score = row['avg_score']
            status = row['most_freq_status']
            rec = "Good Engagement" if score >= 70 else ("Check Gaze & Posture" if status == 'Distracted' else "Check Fatigue / Take Break")
            stu_data.append([f"Student #{int(row['student_id'])}", f"{score:.1f}%", status, rec])

        t_stu = Table(stu_data, colWidths=[80, 120, 120, 180])
        t_stu.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E293B')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F1F5F9')]),
        ]))
        story.append(t_stu)
    else:
        story.append(Paragraph("No log entries recorded for this session.", normal_text))

    story.append(Spacer(1, 15))

    # Sustained Alerts Log
    story.append(Paragraph("Sustained Low-Attention & Fatigue Alerts Log", heading2))
    if not alerts_df.empty:
        alert_data = [['Timestamp', 'Student ID', 'Alert Type', 'Message']]
        for _, row in alerts_df.head(10).iterrows():
            ts_short = row['timestamp'].split('T')[-1][:8] if 'T' in str(row['timestamp']) else str(row['timestamp'])
            alert_data.append([ts_short, f"Student #{int(row['student_id'])}", str(row['alert_type']), str(row['message'])])
        
        t_alert = Table(alert_data, colWidths=[90, 80, 120, 210])
        t_alert.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#991B1B')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#FECACA')),
        ]))
        story.append(t_alert)
    else:
        story.append(Paragraph("No low-attention alerts triggered during this session.", normal_text))

    story.append(Spacer(1, 20))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#94A3B8'), spaceAfter=10))
    story.append(Paragraph("<b>Privacy & Safeguards Notice:</b> This system strictly adheres to the Digital Personal Data Protection (DPDP) Act guidelines. Video processing is executed locally on-device without persisting raw facial video frames.", ParagraphStyle('Foot', parent=styles['Normal'], fontSize=8, textColor=colors.HexColor('#64748B'))))

    doc.build(story)
    return output_path

def generate_html_report(session_id, session_df, alerts_df, output_path):
    """HTML report fallback."""
    avg_attention = session_df['attention_score'].mean() if not session_df.empty else 0.0
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Classroom Engagement Report - {session_id}</title>
        <style>
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f172a; color: #f8fafc; padding: 30px; }}
            .container {{ max-width: 900px; margin: auto; background: #1e293b; padding: 30px; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }}
            h1 {{ color: #38bdf8; border-bottom: 2px solid #38bdf8; padding-bottom: 10px; }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 25px; }}
            th, td {{ padding: 12px; border: 1px solid #334155; text-align: left; }}
            th {{ background: #0f172a; color: #38bdf8; }}
            tr:nth-child(even) {{ background: #1e293b; }}
            .metric {{ font-size: 2em; font-weight: bold; color: #34d399; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Classroom Attention Analytics Report</h1>
            <p>Session ID: {session_id} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <h2>Overall Class Attention: <span class="metric">{avg_attention:.1f}%</span></h2>
            <h3>Log Entries Summary</h3>
            <p>Total Data Frames Recorded: {len(session_df)}</p>
        </div>
    </body>
    </html>
    """
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    return output_path
