"""
Generates a realistic simulated classroom video file (MP4) for testing and demo purposes.
"""
import os
import cv2
import numpy as np

def generate_sample_video(output_path=None, duration_sec=15, fps=20):
    """
    Generates a synthetic classroom MP4 video with 3 animated student faces displaying various behaviors.
    """
    if output_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_path = os.path.join(base_dir, 'assets', 'sample_classroom.mp4')

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    width, height = 1280, 720
    total_frames = duration_sec * fps
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    if not out.isOpened():
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    # Base background (dark classroom setup)
    bg_color = (25, 30, 45) # dark blue-gray

    # Student base positions in frame
    students = [
        {'id': 1, 'center': (320, 360), 'scale': 1.0, 'skin': (180, 210, 240)}, # Student 1
        {'id': 2, 'center': (640, 360), 'scale': 1.0, 'skin': (170, 200, 235)}, # Student 2
        {'id': 3, 'center': (960, 360), 'scale': 1.0, 'skin': (190, 220, 245)}, # Student 3
    ]

    for frame_idx in range(total_frames):
        t = frame_idx / fps
        frame = np.full((height, width, 3), bg_color, dtype=np.uint8)

        # Draw Classroom Desk & Board background elements
        cv2.rectangle(frame, (50, 40), (1230, 140), (40, 50, 70), -1)
        cv2.putText(frame, "CLASSROOM ATTENTION MONITORING DEMO FEED", (80, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (200, 220, 255), 2)

        # Draw Desk rail
        cv2.rectangle(frame, (0, 550), (1280, 720), (35, 45, 60), -1)

        for s in students:
            cx, cy = s['center']
            skin_color = s['skin']
            
            # Default state parameters
            head_shift_x, head_shift_y = 0, 0
            eye_close_factor = 0.0 # 0.0 = open, 1.0 = closed
            yawn_factor = 0.0

            # Dynamic behaviors over time
            if s['id'] == 1:
                # Student 1: Highly attentive, slight breathing movement
                head_shift_y = int(np.sin(t * 2) * 3)
                if int(t) % 4 == 0 and (t - int(t)) < 0.2:
                    eye_close_factor = 0.9 # blink
            
            elif s['id'] == 2:
                # Student 2: Turns head away (Distracted) at t=4s to t=9s
                if 4.0 <= t <= 9.0:
                    head_shift_x = int((t - 4.0) * 15) if t < 6.0 else 30
                    if t > 7.5:
                        head_shift_x = int((9.0 - t) * 20)
                else:
                    head_shift_x = int(np.sin(t * 1.5) * 5)
            
            elif s['id'] == 3:
                # Student 3: Gets Drowsy & Yawns at t=5s to t=12s
                if 5.0 <= t <= 12.0:
                    eye_close_factor = min(1.0, (t - 5.0) * 0.3)
                    head_shift_y = int((t - 5.0) * 4)
                    if 8.0 <= t <= 10.5:
                        yawn_factor = np.sin((t - 8.0) / 2.5 * np.pi)

            # Draw Head Ellipse
            fx, fy = cx + head_shift_x, cy + head_shift_y
            cv2.ellipse(frame, (fx, fy), (90, 120), 0, 0, 360, skin_color, -1)
            cv2.ellipse(frame, (fx, fy), (90, 120), 0, 0, 360, (120, 140, 160), 3)

            # Hair cap
            cv2.ellipse(frame, (fx, fy - 50), (92, 70), 0, 180, 360, (50, 40, 30), -1)

            # Eyes
            eye_off_x = 35
            eye_y = fy - 20
            eye_h = int(14 * (1.0 - eye_close_factor))
            
            # Left Eye
            cv2.ellipse(frame, (fx - eye_off_x, eye_y), (22, max(2, eye_h)), 0, 0, 360, (255, 255, 255), -1)
            cv2.circle(frame, (fx - eye_off_x + int(head_shift_x * 0.2), eye_y), max(1, eye_h - 4), (40, 30, 20), -1)
            
            # Right Eye
            cv2.ellipse(frame, (fx + eye_off_x, eye_y), (22, max(2, eye_h)), 0, 0, 360, (255, 255, 255), -1)
            cv2.circle(frame, (fx + eye_off_x + int(head_shift_x * 0.2), eye_y), max(1, eye_h - 4), (40, 30, 20), -1)

            # Eyebrows
            cv2.line(frame, (fx - eye_off_x - 18, eye_y - 18), (fx - eye_off_x + 18, eye_y - 18), (60, 50, 40), 3)
            cv2.line(frame, (fx + eye_off_x - 18, eye_y - 18), (fx + eye_off_x + 18, eye_y - 18), (60, 50, 40), 3)

            # Nose
            cv2.line(frame, (fx, eye_y), (fx + int(head_shift_x * 0.3), fy + 20), (140, 160, 190), 3)

            # Mouth / Yawn
            mouth_y = fy + 55
            mouth_h = int(8 + (yawn_factor * 35))
            cv2.ellipse(frame, (fx, mouth_y), (28, max(4, mouth_h)), 0, 0, 360, (180, 70, 70), -1)

            # Label student ID tag
            cv2.putText(frame, f"Student #{s['id']}", (fx - 45, fy + 155), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (240, 240, 255), 2)

        out.write(frame)

    out.release()
    print(f"Sample classroom video successfully generated at {output_path}")
    return output_path

if __name__ == '__main__':
    generate_sample_video()
