"""
Face Detection and Facial Landmark Extraction using MediaPipe / OpenCV.
"""
import cv2
import numpy as np
import logging

try:
    import mediapipe as mp
    HAS_MEDIAPIPE = True
except ImportError:
    HAS_MEDIAPIPE = False

logger = logging.getLogger(__name__)

class FaceDetector:
    """
    Detects faces in video frames and extracts 3D facial landmarks (468/478 points).
    Provides OpenCV Haar Cascade fallback if MediaPipe is unavailable.
    """
    def __init__(self, max_num_faces=10, min_detection_confidence=0.5, min_tracking_confidence=0.5):
        self.max_num_faces = max_num_faces
        self.min_detection_confidence = min_detection_confidence
        self.min_tracking_confidence = min_tracking_confidence
        
        self.mp_face_mesh = None
        self.face_mesh = None
        
        if HAS_MEDIAPIPE:
            try:
                self.mp_face_mesh = mp.solutions.face_mesh
                self.face_mesh = self.mp_face_mesh.FaceMesh(
                    static_image_mode=False,
                    max_num_faces=self.max_num_faces,
                    refine_landmarks=True,  # Includes iris landmarks
                    min_detection_confidence=self.min_detection_confidence,
                    min_tracking_confidence=self.min_tracking_confidence
                )
                logger.info("MediaPipe FaceMesh initialized with iris refinement.")
            except Exception as e:
                logger.warning(f"Failed to initialize MediaPipe FaceMesh: {e}. Falling back to OpenCV.")
                self.face_mesh = None

        # Fallback Haar Cascade
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.haar_cascade = cv2.CascadeClassifier(cascade_path)

    def process(self, frame_bgr):
        """
        Process a BGR image frame.
        Returns a list of dictionaries, each containing:
        - bbox: (x, y, w, h)
        - landmarks_3d: np.ndarray shape (N, 3) normalized [0..1]
        - landmarks_px: np.ndarray shape (N, 2) pixel coords (x, y)
        - confidence: float score
        """
        h, w = frame_bgr.shape[:2]
        results = []

        if self.face_mesh is not None:
            rgb_frame = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            mp_results = self.face_mesh.process(rgb_frame)

            if mp_results.multi_face_landmarks:
                for face_landmarks in mp_results.multi_face_landmarks:
                    pts_norm = []
                    pts_px = []
                    
                    for lm in face_landmarks.landmark:
                        pts_norm.append([lm.x, lm.y, lm.z])
                        pts_px.append([int(lm.x * w), int(lm.y * h)])

                    pts_norm = np.array(pts_norm, dtype=np.float32)
                    pts_px = np.array(pts_px, dtype=np.int32)

                    # Calculate bounding box from landmarks
                    x_min, y_min = np.min(pts_px[:, :2], axis=0)
                    x_max, y_max = np.max(pts_px[:, :2], axis=0)
                    
                    # Pad box slightly
                    pad_x = int((x_max - x_min) * 0.1)
                    pad_y = int((y_max - y_min) * 0.15)
                    
                    bx = max(0, x_min - pad_x)
                    by = max(0, y_min - pad_y)
                    bw = min(w - bx, (x_max - x_min) + 2 * pad_x)
                    bh = min(h - by, (y_max - y_min) + 2 * pad_y)

                    results.append({
                        'bbox': (bx, by, bw, bh),
                        'landmarks_3d': pts_norm,
                        'landmarks_px': pts_px,
                        'confidence': 0.95
                    })
                return results

        # Fallback to Haar cascade if MediaPipe unavailable or no faces found
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        faces = self.haar_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))

        for (fx, fy, fw, fh) in faces:
            # Create synthetic landmarks for Haar detection face box
            synthetic_px = self._create_synthetic_landmarks(fx, fy, fw, fh)
            synthetic_norm = synthetic_px.astype(np.float32) / np.array([w, h], dtype=np.float32)
            synthetic_norm_3d = np.hstack([synthetic_norm, np.zeros((len(synthetic_norm), 1), dtype=np.float32)])

            results.append({
                'bbox': (int(fx), int(fy), int(fw), int(fh)),
                'landmarks_3d': synthetic_norm_3d,
                'landmarks_px': synthetic_px,
                'confidence': 0.75
            })

        return results

    def _create_synthetic_landmarks(self, x, y, w, h):
        """Create basic 468 landmark approximation array when only BBox is available."""
        pts = np.zeros((468, 2), dtype=np.int32)
        cx, cy = x + w // 2, y + h // 2
        
        # Nose tip (landmark 1)
        pts[1] = [cx, cy]
        # Chin (landmark 152)
        pts[152] = [cx, y + int(h * 0.95)]
        # Left eye outer corner (landmark 33)
        pts[33] = [x + int(w * 0.3), y + int(h * 0.4)]
        # Right eye outer corner (landmark 263)
        pts[263] = [x + int(w * 0.7), y + int(h * 0.4)]
        # Left mouth corner (landmark 61)
        pts[61] = [x + int(w * 0.35), y + int(h * 0.75)]
        # Right mouth corner (landmark 291)
        pts[291] = [x + int(w * 0.65), y + int(h * 0.75)]
        
        # Fill remaining with center approximations
        for i in range(468):
            if np.all(pts[i] == 0):
                pts[i] = [cx, cy]
        return pts

    def release(self):
        if self.face_mesh:
            self.face_mesh.close()
