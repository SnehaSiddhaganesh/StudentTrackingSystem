"""
3D Head Pose Estimation using OpenCV solvePnP.
Calculates Yaw, Pitch, and Roll angles from facial landmarks.
"""
import cv2
import numpy as np

class HeadPoseEstimator:
    """
    Estimates 3D head pose (Yaw, Pitch, Roll) using OpenCV solvePnP.
    """
    def __init__(self, image_size=(640, 480)):
        h, w = image_size
        focal_length = w
        center = (w / 2, h / 2)
        
        # Camera intrinsic matrix approximation
        self.camera_matrix = np.array([
            [focal_length, 0, center[0]],
            [0, focal_length, center[1]],
            [0, 0, 1]
        ], dtype=np.float64)

        # Assuming no lens distortion
        self.dist_coeffs = np.zeros((4, 1), dtype=np.float64)

        # Standard 3D facial model points (in mm/arbitrary world units)
        # 1: Nose tip, 152: Chin, 33: Left eye outer corner, 263: Right eye outer corner, 61: Left mouth corner, 291: Right mouth corner
        self.model_points_3d = np.array([
            (0.0, 0.0, 0.0),             # Nose tip
            (0.0, -330.0, -65.0),        # Chin
            (-225.0, 170.0, -135.0),     # Left eye outer corner
            (225.0, 170.0, -135.0),      # Right eye outer corner
            (-150.0, -150.0, -125.0),    # Left mouth corner
            (150.0, -150.0, -125.0)      # Right mouth corner
        ], dtype=np.float64)

        # Landmark indices in MediaPipe FaceMesh
        self.landmark_indices = [1, 152, 33, 263, 61, 291]

    def estimate_pose(self, landmarks_px, frame_shape):
        """
        Estimate Head Pose (Yaw, Pitch, Roll) from pixel facial landmarks.
        
        Returns:
            dict containing:
            - yaw: float (-90 to +90 degrees, positive = turning right)
            - pitch: float (-90 to +90 degrees, positive = looking down)
            - roll: float (-90 to +90 degrees, positive = tilting right)
            - pose_score: float normalized [0.0 to 1.0] representing frontality
            - rvec: rotation vector
            - tvec: translation vector
            - nose_proj: projected nose direction point for visualization
        """
        h, w = frame_shape[:2]
        
        # Dynamically adjust camera matrix if frame dimensions change
        focal_length = w
        camera_matrix = np.array([
            [focal_length, 0, w / 2],
            [0, focal_length, h / 2],
            [0, 0, 1]
        ], dtype=np.float64)

        # Extract the 6 key 2D landmark points
        image_points = []
        for idx in self.landmark_indices:
            if idx < len(landmarks_px):
                image_points.append(landmarks_px[idx])
            else:
                image_points.append([w // 2, h // 2])
        
        image_points = np.array(image_points, dtype=np.float64)

        # Solve Perspective-n-Point
        success, rvec, tvec = cv2.solvePnP(
            self.model_points_3d,
            image_points,
            camera_matrix,
            self.dist_coeffs,
            flags=cv2.SOLVEPNP_ITERATIVE
        )

        if not success:
            return {
                'yaw': 0.0,
                'pitch': 0.0,
                'roll': 0.0,
                'pose_score': 1.0,
                'rvec': np.zeros((3, 1)),
                'tvec': np.zeros((3, 1)),
                'nose_proj': (int(image_points[0][0]), int(image_points[0][1]))
            }

        # Convert rotation vector to rotation matrix
        rmat, _ = cv2.Rodrigues(rvec)
        
        # Compute Euler Angles (Yaw, Pitch, Roll)
        # Using decomposeProjectionMatrix or Euler formula
        proj_matrix = np.hstack((rmat, tvec))
        _, _, _, _, _, _, euler_angles = cv2.decomposeProjectionMatrix(proj_matrix)
        
        pitch = float(euler_angles[0][0])
        yaw = float(euler_angles[1][0])
        roll = float(euler_angles[2][0])

        # Normalize angles to [-180, 180]
        yaw = np.clip(yaw, -90.0, 90.0)
        pitch = np.clip(pitch, -90.0, 90.0)
        roll = np.clip(roll, -90.0, 90.0)

        # Calculate pose frontality score: 1.0 = looking straight at camera, 0.0 = turned far away
        angular_deviation = np.sqrt(yaw**2 + pitch**2 + (roll * 0.5)**2)
        pose_score = float(np.clip(1.0 - (angular_deviation / 60.0), 0.0, 1.0))

        # Project a 3D line forward from the nose tip for visual direction vector
        nose_end_point3D = np.array([[0.0, 0.0, 500.0]], dtype=np.float64)
        nose_end_point2D, _ = cv2.projectPoints(
            nose_end_point3D, rvec, tvec, camera_matrix, self.dist_coeffs
        )
        
        nose_p1 = (int(image_points[0][0]), int(image_points[0][1]))
        nose_p2 = (int(nose_end_point2D[0][0][0]), int(nose_end_point2D[0][0][1]))

        return {
            'yaw': yaw,
            'pitch': pitch,
            'roll': roll,
            'pose_score': pose_score,
            'rvec': rvec,
            'tvec': tvec,
            'nose_start': nose_p1,
            'nose_end': nose_p2
        }
