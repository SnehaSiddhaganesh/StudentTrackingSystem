"""
Multi-Student Persistent ID Tracker with Exponential Moving Average (EMA) Smoothing.
"""
import numpy as np

class TrackedStudent:
    """
    Maintains temporal state for an individual student face track.
    """
    def __init__(self, student_id, initial_bbox):
        self.student_id = student_id
        self.bbox = initial_bbox  # (x, y, w, h)
        self.centroid = (initial_bbox[0] + initial_bbox[2] // 2, initial_bbox[1] + initial_bbox[3] // 2)
        
        # Exponential Moving Average (EMA) state
        self.attention_score_ema = 85.0  # Default starting attention score
        self.alpha = 0.25  # EMA smoothing factor
        
        self.disappeared_frames = 0
        self.total_frames_tracked = 0
        self.status_history = []
        self.sustained_low_attention_frames = 0

    def update(self, bbox, current_attention_score, status):
        """Update tracker state with new frame detection."""
        self.bbox = bbox
        self.centroid = (bbox[0] + bbox[2] // 2, bbox[1] + bbox[3] // 2)
        self.disappeared_frames = 0
        self.total_frames_tracked += 1

        # Apply EMA smoothing: EMA_new = alpha * current + (1 - alpha) * EMA_old
        self.attention_score_ema = (self.alpha * current_attention_score) + ((1.0 - self.alpha) * self.attention_score_ema)

        self.status_history.append(status)
        if len(self.status_history) > 60:
            self.status_history.pop(0)

        if status in ['Distracted', 'Drowsy']:
            self.sustained_low_attention_frames += 1
        else:
            self.sustained_low_attention_frames = max(0, self.sustained_low_attention_frames - 1)


class StudentTracker:
    """
    Tracks multiple student faces across frames using Centroid / IoU matching.
    """
    def __init__(self, max_disappeared=30, max_distance=120):
        self.next_student_id = 1
        self.students = {}  # student_id -> TrackedStudent
        self.max_disappeared = max_disappeared
        self.max_distance = max_distance

    def update(self, detections, attention_results):
        """
        Match incoming frame detections to existing student tracks.
        
        Args:
            detections: list of dicts with 'bbox'
            attention_results: list of dicts with 'attention_score' and 'status'
            
        Returns:
            list of dicts containing tracked student metadata
        """
        updated_tracks = []

        if len(detections) == 0:
            # Mark all existing tracks as disappeared
            for sid in list(self.students.keys()):
                self.students[sid].disappeared_frames += 1
                if self.students[sid].disappeared_frames > self.max_disappeared:
                    del self.students[sid]
            return updated_tracks

        # Prepare input centroids
        input_centroids = []
        for det in detections:
            x, y, w, h = det['bbox']
            input_centroids.append((x + w // 2, y + h // 2))

        # If no active student tracks, register all as new
        if len(self.students) == 0:
            for i, det in enumerate(detections):
                self._register_student(det['bbox'], attention_results[i]['attention_score'], attention_results[i]['status'])
        else:
            # Match existing tracks to input centroids
            student_ids = list(self.students.keys())
            existing_centroids = [self.students[sid].centroid for sid in student_ids]

            # Compute Euclidean distance matrix
            dist_matrix = np.zeros((len(existing_centroids), len(input_centroids)), dtype=np.float32)
            for i, ec in enumerate(existing_centroids):
                for j, ic in enumerate(input_centroids):
                    dist_matrix[i, j] = np.linalg.norm(np.array(ec) - np.array(ic))

            # Greedy Hungarian-style matching
            used_rows = set()
            used_cols = set()

            # Find minimum distance pairs
            min_indices = np.argsort(dist_matrix.values if hasattr(dist_matrix, 'values') else dist_matrix, axis=None)
            for flat_idx in min_indices:
                row = flat_idx // len(input_centroids)
                col = flat_idx % len(input_centroids)

                if row in used_rows or col in used_cols:
                    continue

                if dist_matrix[row, col] > self.max_distance:
                    continue

                # Match found! Update tracked student
                sid = student_ids[row]
                att = attention_results[col]
                self.students[sid].update(detections[col]['bbox'], att['attention_score'], att['status'])

                used_rows.add(row)
                used_cols.add(col)

            # Register unmatched new detections
            for j in range(len(input_centroids)):
                if j not in used_cols:
                    self._register_student(detections[j]['bbox'], attention_results[j]['attention_score'], attention_results[j]['status'])

            # Handle unmatched existing tracks
            for i in range(len(existing_centroids)):
                if i not in used_rows:
                    sid = student_ids[i]
                    self.students[sid].disappeared_frames += 1
                    if self.students[sid].disappeared_frames > self.max_disappeared:
                        del self.students[sid]

        # Compile final outputs
        for sid, student in self.students.items():
            if student.disappeared_frames == 0:
                updated_tracks.append({
                    'student_id': student.student_id,
                    'bbox': student.bbox,
                    'smoothed_attention': student.attention_score_ema,
                    'sustained_low_count': student.sustained_low_attention_frames
                })

        return updated_tracks

    def _register_student(self, bbox, score, status):
        student = TrackedStudent(self.next_student_id, bbox)
        student.update(bbox, score, status)
        self.students[self.next_student_id] = student
        self.next_student_id += 1
