"""
Drowsiness and Fatigue Detector calculating Eye Aspect Ratio (EAR) and Mouth Aspect Ratio (MAR).
"""
import numpy as np

class DrowsinessDetector:
    """
    Measures facial fatigue, eye closure (EAR), blinks, and yawning (MAR).
    """
    # MediaPipe landmark indices for left and right eyes
    # Left eye: 33 (outer), 160 (top1), 158 (top2), 133 (inner), 153 (bot2), 144 (bot1)
    LEFT_EYE = [33, 160, 158, 133, 153, 144]
    # Right eye: 362 (inner), 385 (top1), 387 (top2), 263 (outer), 373 (bot2), 380 (bot1)
    RIGHT_EYE = [362, 385, 387, 263, 373, 380]
    
    # Mouth landmarks: 61 (left corner), 291 (right corner), 13 (top lip center), 14 (bot lip center), etc.
    MOUTH = [61, 185, 40, 39, 37, 0, 267, 269, 270, 409, 291, 375, 321, 405, 314, 17, 84, 181, 91, 146]
    MOUTH_TOP_BOT = [(13, 14), (82, 87), (312, 317)]
    MOUTH_CORNER = (61, 291)

    def __init__(self, ear_threshold=0.21, mar_threshold=0.60, consecutive_frames_threshold=12):
        self.ear_threshold = ear_threshold
        self.mar_threshold = mar_threshold
        self.consecutive_frames_threshold = consecutive_frames_threshold

    def calculate_ear(self, landmarks_px, eye_indices):
        """
        Calculate Eye Aspect Ratio (EAR) for a single eye given landmark indices.
        EAR = (||p2 - p6|| + ||p3 - p5||) / (2 * ||p1 - p4||)
        """
        if len(landmarks_px) <= max(eye_indices):
            return 0.3 # default open eye value

        p1 = landmarks_px[eye_indices[0]] # outer corner
        p2 = landmarks_px[eye_indices[1]] # top 1
        p3 = landmarks_px[eye_indices[2]] # top 2
        p4 = landmarks_px[eye_indices[3]] # inner corner
        p5 = landmarks_px[eye_indices[4]] # bot 2
        p6 = landmarks_px[eye_indices[5]] # bot 1

        v1 = np.linalg.norm(p2 - p6)
        v2 = np.linalg.norm(p3 - p5)
        h = np.linalg.norm(p1 - p4)

        if h < 1e-6:
            return 0.3

        ear = (v1 + v2) / (2.0 * h)
        return float(ear)

    def calculate_mar(self, landmarks_px):
        """
        Calculate Mouth Aspect Ratio (MAR) for mouth opening / yawning.
        """
        if len(landmarks_px) <= 317:
            return 0.1

        # Vertical distances
        v1 = np.linalg.norm(landmarks_px[13] - landmarks_px[14])
        v2 = np.linalg.norm(landmarks_px[82] - landmarks_px[87])
        v3 = np.linalg.norm(landmarks_px[312] - landmarks_px[317])
        
        # Horizontal distance
        h = np.linalg.norm(landmarks_px[61] - landmarks_px[291])

        if h < 1e-6:
            return 0.1

        mar = (v1 + v2 + v3) / (3.0 * h)
        return float(mar)

    def process(self, landmarks_px):
        """
        Process landmarks and return drowsiness and fatigue metrics.
        
        Returns:
            dict containing:
            - left_ear: float
            - right_ear: float
            - avg_ear: float
            - mar: float
            - is_drowsy: bool (True if EAR < threshold)
            - is_yawning: bool (True if MAR > threshold)
            - drowsiness_score: float [0.0 to 1.0] where 1.0 is fully alert and 0.0 is sleeping/drowsy
        """
        left_ear = self.calculate_ear(landmarks_px, self.LEFT_EYE)
        right_ear = self.calculate_ear(landmarks_px, self.RIGHT_EYE)
        avg_ear = (left_ear + right_ear) / 2.0
        mar = self.calculate_mar(landmarks_px)

        is_drowsy = avg_ear < self.ear_threshold
        is_yawning = mar > self.mar_threshold

        # Drowsiness score: 1.0 = eyes wide open, 0.0 = eyes closed
        drowsiness_score = float(np.clip(avg_ear / 0.30, 0.0, 1.0))
        if is_yawning:
            drowsiness_score = min(drowsiness_score, 0.4)

        return {
            'left_ear': left_ear,
            'right_ear': right_ear,
            'avg_ear': avg_ear,
            'mar': mar,
            'is_drowsy': is_drowsy,
            'is_yawning': is_yawning,
            'drowsiness_score': drowsiness_score
        }
