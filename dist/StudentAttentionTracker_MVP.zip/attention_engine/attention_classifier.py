"""
Attention Classifier combining XGBoost Machine Learning Model with Rule-Based Fallbacks.
Classifies student engagement status into Attentive, Distracted, or Drowsy.
"""
import os
import pickle
import numpy as np
import logging

try:
    import xgboost as xgb
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

logger = logging.getLogger(__name__)

class AttentionClassifier:
    """
    ML + Rule-based hybrid classifier for classroom attention scoring.
    """
    FEATURE_NAMES = [
        'head_yaw', 'head_pitch', 'head_roll',
        'gaze_x', 'gaze_y', 'avg_ear', 'mar',
        'pose_score', 'gaze_score', 'drowsiness_score'
    ]

    def __init__(self, model_path=None):
        if model_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            model_path = os.path.join(base_dir, 'models', 'xgboost_attention.pkl')
            
        self.model_path = model_path
        self.model = None
        self._load_model()

    def _load_model(self):
        """Load trained XGBoost model if available."""
        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, 'rb') as f:
                    self.model = pickle.load(f)
                logger.info(f"Successfully loaded XGBoost model from {self.model_path}")
            except Exception as e:
                logger.warning(f"Could not load XGBoost model: {e}. Will use rule-based scoring.")
                self.model = None
        else:
            logger.info("Trained XGBoost model file not found yet. Using rule-based scoring.")

    def classify(self, head_pose, gaze, drowsiness):
        """
        Classify student attention state from visual cues.
        
        Args:
            head_pose: dict from HeadPoseEstimator
            gaze: dict from GazeEstimator
            drowsiness: dict from DrowsinessDetector
            
        Returns:
            dict containing:
            - status: str ('Attentive', 'Distracted', 'Drowsy')
            - attention_score: float [0.0 - 100.0]
            - confidence: float [0.0 - 1.0]
            - feature_vector: list of floats
        """
        feature_vector = [
            head_pose['yaw'],
            head_pose['pitch'],
            head_pose['roll'],
            gaze['gaze_x'],
            gaze['gaze_y'],
            drowsiness['avg_ear'],
            drowsiness['mar'],
            head_pose['pose_score'],
            gaze['gaze_score'],
            drowsiness['drowsiness_score']
        ]

        # Use XGBoost model if loaded
        if self.model is not None and HAS_XGBOOST:
            try:
                X = np.array([feature_vector], dtype=np.float32)
                preds_proba = self.model.predict_proba(X)[0]
                pred_class_idx = np.argmax(preds_proba)
                
                # Class mapping: 0 -> Attentive, 1 -> Distracted, 2 -> Drowsy
                classes = ['Attentive', 'Distracted', 'Drowsy']
                status = classes[pred_class_idx]
                
                # Attention score calculation based on predicted probability
                raw_score = (preds_proba[0] * 100.0) + (preds_proba[1] * 40.0) + (preds_proba[2] * 10.0)
                attention_score = float(np.clip(raw_score, 0.0, 100.0))
                confidence = float(preds_proba[pred_class_idx])

                return {
                    'status': status,
                    'attention_score': attention_score,
                    'confidence': confidence,
                    'feature_vector': feature_vector
                }
            except Exception as e:
                logger.warning(f"Error during XGBoost inference: {e}. Falling back to rule engine.")

        # Rule-Based Inference Fallback
        return self._rule_based_classify(head_pose, gaze, drowsiness, feature_vector)

    def _rule_based_classify(self, head_pose, gaze, drowsiness, feature_vector):
        """Calculates precise attention score using weighted heuristic rule engine."""
        pose_score = head_pose['pose_score']        # Weight: 0.35
        gaze_score = gaze['gaze_score']              # Weight: 0.35
        drowsiness_score = drowsiness['drowsiness_score'] # Weight: 0.30

        # Primary score out of 100
        raw_attention = (pose_score * 35.0) + (gaze_score * 35.0) + (drowsiness_score * 30.0)
        
        # Penalize excessive head yaw/pitch
        if abs(head_pose['yaw']) > 35 or abs(head_pose['pitch']) > 30:
            raw_attention -= 25.0
            
        # Penalize severe eye closure / yawning
        if drowsiness['is_drowsy'] or drowsiness['is_yawning']:
            raw_attention -= 35.0

        attention_score = float(np.clip(raw_attention, 0.0, 100.0))

        # Status categorization
        if drowsiness['is_drowsy'] or drowsiness['avg_ear'] < 0.20:
            status = 'Drowsy'
        elif attention_score >= 65.0 and abs(head_pose['yaw']) < 25.0:
            status = 'Attentive'
        else:
            status = 'Distracted'

        return {
            'status': status,
            'attention_score': attention_score,
            'confidence': 0.88,
            'feature_vector': feature_vector
        }
