"""
Gaze Estimation Engine based on Iris landmarks and Head Pose.
Estimates visual gaze direction and focus relative to the screen/board center.
"""
import numpy as np

class GazeEstimator:
    """
    Tracks iris position relative to eye boundaries to calculate gaze vector and focus score.
    """
    # MediaPipe landmark indices for Eyes and Irises
    LEFT_EYE_LANDMARKS = [33, 160, 158, 133, 153, 144]
    RIGHT_EYE_LANDMARKS = [362, 385, 387, 263, 373, 380]
    
    # Iris refined landmarks in MediaPipe
    LEFT_IRIS = [468, 469, 470, 471, 472]
    RIGHT_IRIS = [473, 474, 475, 476, 477]

    def estimate_gaze(self, landmarks_px, head_pose, frame_shape):
        """
        Estimate gaze direction vector and focus score.
        
        Args:
            landmarks_px: np.ndarray of shape (N, 2)
            head_pose: dict from HeadPoseEstimator
            frame_shape: tuple (h, w, c)
            
        Returns:
            dict containing:
            - gaze_x: float [-1.0, 1.0] (negative = left, positive = right)
            - gaze_y: float [-1.0, 1.0] (negative = up, positive = down)
            - gaze_score: float [0.0, 1.0] focus score towards screen center
            - iris_left_px: tuple (x, y)
            - iris_right_px: tuple (x, y)
        """
        h, w = frame_shape[:2]
        num_landmarks = len(landmarks_px)

        # Default fallback iris positions
        iris_left_px = (int(w * 0.4), int(h * 0.4))
        iris_right_px = (int(w * 0.6), int(h * 0.4))

        if num_landmarks >= 478:
            # MediaPipe refined iris landmarks available
            iris_left_px = (int(landmarks_px[468][0]), int(landmarks_px[468][1]))
            iris_right_px = (int(landmarks_px[473][0]), int(landmarks_px[473][1]))

            # Compute eye horizontal center and iris relative displacement
            left_corner = landmarks_px[33]
            right_corner = landmarks_px[133]
            eye_width_left = max(1.0, np.linalg.norm(left_corner - right_corner))
            iris_rel_left = (landmarks_px[468][0] - left_corner[0]) / eye_width_left - 0.5

            r_left_corner = landmarks_px[362]
            r_right_corner = landmarks_px[263]
            eye_width_right = max(1.0, np.linalg.norm(r_left_corner - r_right_corner))
            iris_rel_right = (landmarks_px[473][0] - r_left_corner[0]) / eye_width_right - 0.5

            iris_gaze_h = (iris_rel_left + iris_rel_right) / 2.0
        else:
            # Fallback estimation using head pose yaw as dominant gaze proxy
            iris_gaze_h = head_pose['yaw'] / 90.0

        # Combine iris relative displacement with head yaw/pitch
        gaze_x = float(np.clip(iris_gaze_h * 2.0 + (head_pose['yaw'] / 45.0), -1.0, 1.0))
        gaze_y = float(np.clip((head_pose['pitch'] / 45.0), -1.0, 1.0))

        # Gaze focus score: 1.0 = gazing straight at blackboard/camera, 0.0 = gazing away
        gaze_dist = np.sqrt(gaze_x**2 + gaze_y**2)
        gaze_score = float(np.clip(1.0 - (gaze_dist / 0.8), 0.0, 1.0))

        return {
            'gaze_x': gaze_x,
            'gaze_y': gaze_y,
            'gaze_score': gaze_score,
            'iris_left_px': iris_left_px,
            'iris_right_px': iris_right_px
        }
