# 🎓 AI-Based Classroom Attention Monitoring System

> **High-Performance Computer Vision & ML Analytics MVP for Classroom Engagement Monitoring**
> *Prepared for submission to RB Tech Services for Internship Selection.*

---

## 🌟 Executive Overview

In physical and hybrid classroom environments, educators face challenges in objectively gauging real-time student attentiveness, engagement, and fatigue. The **AI-Based Classroom Attention Monitoring System** provides a lightweight, real-time visual analytics solution that monitors classrooms, tracks multi-student engagement cues, and detects dips in attention — **without requiring expensive proprietary hardware or paid cloud AI APIs**.

---

## ✨ Key Features & Technical Highlights

1. **Multi-Person Face & 3D Landmark Tracking**:
   - Extracts 468/478 3D facial landmarks per student using **MediaPipe Face Mesh** with high performance.
   - Robust fallback to OpenCV Haar Cascades for low-resource CPUs.

2. **3D Head Pose Estimation**:
   - Uses OpenCV `solvePnP` with standard 3D facial geometry to compute **Yaw** (left/right head turn), **Pitch** (up/down tilt), and **Roll** in degrees.

3. **Gaze & Focus Vector Calculation**:
   - Tracks iris movement and pupil relative positioning to determine visual gaze vector $(gaze_x, gaze_y)$ relative to the blackboard/screen center.

4. **Drowsiness & Fatigue Detection**:
   - Computes real-time **Eye Aspect Ratio (EAR)** for blink frequency, prolonged eye closure, and micro-sleeps.
   - Computes **Mouth Aspect Ratio (MAR)** for yawn detection.

5. **Multi-Student Persistent ID Tracking & Temporal Smoothing**:
   - Tracks persistent student IDs (`Student #1`, `Student #2`, etc.) across video frames.
   - Uses **Exponential Moving Average (EMA)** smoothing $(\alpha = 0.25)$ to eliminate posture flicker and frame glitches.

6. **XGBoost Machine Learning Classifier**:
   - Trains an **XGBoost** model on facial posture feature vectors (`head_yaw`, `head_pitch`, `gaze_x`, `gaze_y`, `ear`, `mar`, `pose_score`, `gaze_score`, `drowsiness_score`) to classify students into:
     - 🟢 **Attentive** (Focused on lecture content)
     - 🟡 **Distracted** (Looking away / turned posture)
     - 🔴 **Drowsy** (Eyes closed / fatigue / yawning)

7. **State-of-the-Art Dark Glassmorphism Streamlit UI**:
   - Deep space navy theme (`#0F172A`) with glowing neon metric cards and status badges.
   - Real-time video canvas with visual bounding boxes, pose direction vectors, and gaze badges.
   - Real-time interactive **Plotly** class attention trendlines.
   - Sustained low-attention alert feed with configurable thresholds.

8. **Exportable PDF & HTML Session Reports**:
   - One-click post-session PDF report generation featuring class executive summaries, student breakdown tables, and alert logs.

9. **Privacy & DPDP Compliance Safeguards**:
   - Features real-time facial anonymization (blurring/pixelation) and student ID masking options.
   - Operates entirely locally on-device without cloud data leakage.

10. **One-Click Internship Zip Submission**:
    - Built-in `create_project_zip()` script that packages the entire codebase into `StudentAttentionTracker_MVP.zip`.

---

## 📁 Repository Structure

```
StudentAttentionTracker/
├── app.py                      # Main Streamlit Dashboard Application
├── requirements.txt            # Package Dependencies
├── README.md                   # Complete Documentation
├── assets/
│   ├── style.css               # Premium Dark Glassmorphism CSS Theme
│   └── sample_classroom.mp4    # Generated Demo Video Stream
├── attention_engine/
│   ├── __init__.py
│   ├── face_detector.py        # MediaPipe & OpenCV Face Landmark Extractor
│   ├── head_pose.py            # 3D Head Pose Estimator (solvePnP)
│   ├── gaze_estimator.py       # Iris Gaze Tracking & Focus Vector
│   ├── drowsiness_detector.py  # EAR & MAR Drowsiness & Yawn Engine
│   ├── student_tracker.py      # Multi-Student Persistent ID & EMA Tracker
│   └── attention_classifier.py # XGBoost ML & Rule Engine Classifier
├── database/
│   ├── __init__.py
│   └── db_manager.py           # SQLite Database Logging & Query Manager
├── training/
│   ├── __init__.py
│   └── train_model.py          # Synthetic Dataset Generator & XGBoost Trainer
├── utils/
│   ├── __init__.py
│   ├── sample_generator.py     # Classroom Video Generator
│   ├── report_generator.py     # PDF & HTML Session Analytics Report Generator
│   └── packager.py             # Project ZIP Submission Tool
└── models/
    └── xgboost_attention.pkl   # Pre-trained XGBoost Model
```

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
- Python 3.10, 3.11, or 3.12 (Python 3.13 supported)
- Webcam (Optional; system includes a synthetic classroom demo video feed out-of-the-box!)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run the Dashboard
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 📊 Analytics & Reporting

1. **Live Stream View**: Select between **🎥 Demo Classroom Video**, **📹 Upload Video File**, or **📷 Live Webcam Feed**.
2. **Alerts Panel**: Triggers real-time alerts whenever a student exhibits sustained low attention / eye closure for > 4 seconds.
3. **Export PDF**: Click **"Export Session PDF Report"** at the bottom of the dashboard to generate a submission-ready PDF analytics report.

---

## 🛡️ Privacy & Safeguards Model

To ensure ethical deployment in educational institutions and compliance with India's **Digital Personal Data Protection (DPDP) Act**:
- **Data Minimization**: Raw video frames are processed transiently in RAM and never saved to disk.
- **Anonymization Mode**: Optional single-click face blur on the live stream.
- **Local On-Device Execution**: Zero video data sent to third-party cloud servers.

---

## 👨‍💻 Submission Info
- **Project**: AI-Based Classroom Attention Monitoring System (MVP)
- **Target Recipient**: RB Tech Services
- **Status**: Production-Ready MVP
