"""
SQLite Database Manager for logging real-time classroom attention, alerts, and sessions.
"""
import sqlite3
import os
import pandas as pd
from datetime import datetime

class DatabaseManager:
    """
    Manages SQLite database storage for monitoring sessions, student attention logs, and low-attention alerts.
    """
    def __init__(self, db_path=None):
        if db_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_dir, 'database', 'classroom_attention.db')
            
        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _get_connection(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        """Initialize database tables if they do not exist."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Sessions Table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    session_name TEXT,
                    start_time TEXT,
                    end_time TEXT,
                    duration_sec INTEGER DEFAULT 0,
                    avg_attention REAL DEFAULT 0.0,
                    total_students INTEGER DEFAULT 0
                )
            ''')
            
            # Attention Logs Table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attention_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    timestamp TEXT,
                    student_id INTEGER,
                    attention_score REAL,
                    status TEXT,
                    head_yaw REAL,
                    head_pitch REAL,
                    avg_ear REAL,
                    gaze_score REAL,
                    FOREIGN KEY (session_id) REFERENCES sessions (session_id)
                )
            ''')
            
            # Alerts Table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    timestamp TEXT,
                    student_id INTEGER,
                    alert_type TEXT,
                    message TEXT,
                    FOREIGN KEY (session_id) REFERENCES sessions (session_id)
                )
            ''')
            conn.commit()

    def create_session(self, session_id, session_name="Classroom Lecture"):
        """Create a new classroom monitoring session."""
        start_time = datetime.now().isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sessions (session_id, session_name, start_time)
                VALUES (?, ?, ?)
            ''', (session_id, session_name, start_time))
            conn.commit()

    def log_student_attention(self, session_id, student_id, attention_score, status, head_yaw, head_pitch, avg_ear, gaze_score):
        """Log real-time attention metric entry for a student."""
        timestamp = datetime.now().isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO attention_logs (session_id, timestamp, student_id, attention_score, status, head_yaw, head_pitch, avg_ear, gaze_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (session_id, timestamp, student_id, attention_score, status, head_yaw, head_pitch, avg_ear, gaze_score))
            conn.commit()

    def log_alert(self, session_id, student_id, alert_type, message):
        """Log low attention / drowsiness alert."""
        timestamp = datetime.now().isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO alerts (session_id, timestamp, student_id, alert_type, message)
                VALUES (?, ?, ?, ?, ?)
            ''', (session_id, timestamp, student_id, alert_type, message))
            conn.commit()

    def end_session(self, session_id, total_students=0):
        """End session and calculate summary stats."""
        end_time = datetime.now().isoformat()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Compute average attention score across all logs for session
            cursor.execute('SELECT AVG(attention_score) FROM attention_logs WHERE session_id = ?', (session_id,))
            res = cursor.fetchone()
            avg_attention = res[0] if res and res[0] is not None else 0.0

            cursor.execute('''
                UPDATE sessions
                SET end_time = ?, avg_attention = ?, total_students = ?
                WHERE session_id = ?
            ''', (end_time, avg_attention, total_students, session_id))
            conn.commit()

    def get_session_logs_df(self, session_id):
        """Get pandas DataFrame of attention logs for a session."""
        with self._get_connection() as conn:
            df = pd.read_sql_query('''
                SELECT timestamp, student_id, attention_score, status, head_yaw, head_pitch, avg_ear, gaze_score
                FROM attention_logs
                WHERE session_id = ?
                ORDER BY id ASC
            ''', conn, params=(session_id,))
        return df

    def get_session_alerts_df(self, session_id):
        """Get pandas DataFrame of alerts for a session."""
        with self._get_connection() as conn:
            df = pd.read_sql_query('''
                SELECT timestamp, student_id, alert_type, message
                FROM alerts
                WHERE session_id = ?
                ORDER BY id DESC
            ''', conn, params=(session_id,))
        return df

    def get_all_sessions(self):
        """Get summary list of all recorded sessions."""
        with self._get_connection() as conn:
            df = pd.read_sql_query('''
                SELECT session_id, session_name, start_time, end_time, avg_attention, total_students
                FROM sessions
                ORDER BY start_time DESC
            ''', conn)
        return df
