"""
Synthetic Feature Generator & ML Attention Model Trainer.
Trains Random Forest / Gradient Boosting / XGBoost Classifier for Classroom Attention Scoring.
"""
import os
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

try:
    import xgboost as xgb
    HAS_XGBOOST = True
except ImportError:
    HAS_XGBOOST = False

def generate_synthetic_dataset(n_samples=3000):
    """
    Generate synthetic classroom facial geometry feature vectors for training.
    
    Classes:
    0: Attentive
    1: Distracted
    2: Drowsy
    """
    np.random.seed(42)
    samples_per_class = n_samples // 3

    # --- Class 0: Attentive ---
    yaw_0 = np.random.normal(0.0, 8.0, samples_per_class)
    pitch_0 = np.random.normal(-2.0, 6.0, samples_per_class)
    roll_0 = np.random.normal(0.0, 4.0, samples_per_class)
    gaze_x_0 = np.random.normal(0.0, 0.15, samples_per_class)
    gaze_y_0 = np.random.normal(0.0, 0.15, samples_per_class)
    ear_0 = np.random.uniform(0.26, 0.38, samples_per_class)
    mar_0 = np.random.uniform(0.05, 0.25, samples_per_class)
    pose_score_0 = np.random.uniform(0.80, 1.0, samples_per_class)
    gaze_score_0 = np.random.uniform(0.80, 1.0, samples_per_class)
    drowsiness_score_0 = np.random.uniform(0.85, 1.0, samples_per_class)
    y_0 = np.zeros(samples_per_class, dtype=int)

    # --- Class 1: Distracted ---
    yaw_1 = np.random.choice([-1, 1], samples_per_class) * np.random.uniform(25.0, 65.0, samples_per_class)
    pitch_1 = np.random.choice([-1, 1], samples_per_class) * np.random.uniform(18.0, 45.0, samples_per_class)
    roll_1 = np.random.normal(0.0, 12.0, samples_per_class)
    gaze_x_1 = np.random.choice([-1, 1], samples_per_class) * np.random.uniform(0.4, 0.9, samples_per_class)
    gaze_y_1 = np.random.choice([-1, 1], samples_per_class) * np.random.uniform(0.3, 0.8, samples_per_class)
    ear_1 = np.random.uniform(0.23, 0.36, samples_per_class)
    mar_1 = np.random.uniform(0.05, 0.30, samples_per_class)
    pose_score_1 = np.random.uniform(0.1, 0.55, samples_per_class)
    gaze_score_1 = np.random.uniform(0.1, 0.55, samples_per_class)
    drowsiness_score_1 = np.random.uniform(0.70, 0.95, samples_per_class)
    y_1 = np.ones(samples_per_class, dtype=int)

    # --- Class 2: Drowsy ---
    yaw_2 = np.random.normal(0.0, 15.0, samples_per_class)
    pitch_2 = np.random.uniform(15.0, 45.0, samples_per_class)
    roll_2 = np.random.normal(0.0, 10.0, samples_per_class)
    gaze_x_2 = np.random.normal(0.0, 0.3, samples_per_class)
    gaze_y_2 = np.random.uniform(0.3, 0.8, samples_per_class)
    ear_2 = np.random.uniform(0.05, 0.19, samples_per_class)
    mar_2 = np.random.uniform(0.35, 0.85, samples_per_class)
    pose_score_2 = np.random.uniform(0.4, 0.7, samples_per_class)
    gaze_score_2 = np.random.uniform(0.2, 0.6, samples_per_class)
    drowsiness_score_2 = np.random.uniform(0.0, 0.40, samples_per_class)
    y_2 = np.full(samples_per_class, 2, dtype=int)

    X = np.vstack([
        np.column_stack([yaw_0, pitch_0, roll_0, gaze_x_0, gaze_y_0, ear_0, mar_0, pose_score_0, gaze_score_0, drowsiness_score_0]),
        np.column_stack([yaw_1, pitch_1, roll_1, gaze_x_1, gaze_y_1, ear_1, mar_1, pose_score_1, gaze_score_1, drowsiness_score_1]),
        np.column_stack([yaw_2, pitch_2, roll_2, gaze_x_2, gaze_y_2, ear_2, mar_2, pose_score_2, gaze_score_2, drowsiness_score_2])
    ])
    y = np.concatenate([y_0, y_1, y_2])
    return X, y

def train_xgboost_model(output_path=None):
    """
    Trains ML Classifier (GradientBoosting / Random Forest / XGBoost) and saves pickle file.
    """
    if output_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_path = os.path.join(base_dir, 'models', 'xgboost_attention.pkl')

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    print("Generating synthetic classroom feature dataset...")
    X, y = generate_synthetic_dataset(n_samples=3600)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    if HAS_XGBOOST:
        print("Training XGBoost Classifier...")
        model = xgb.XGBClassifier(
            n_estimators=120, max_depth=5, learning_rate=0.08,
            subsample=0.8, colsample_bytree=0.8, random_state=42, eval_metric='mlogloss'
        )
    else:
        print("XGBoost package downloading... Training High-Accuracy GradientBoosting Classifier...")
        model = GradientBoostingClassifier(
            n_estimators=100, max_depth=5, learning_rate=0.08, random_state=42
        )

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"ML Attention Model Validation Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, y_pred, target_names=['Attentive', 'Distracted', 'Drowsy']))

    with open(output_path, 'wb') as f:
        pickle.dump(model, f)
    print(f"Saved trained ML model to {output_path}")
    return model

if __name__ == '__main__':
    train_xgboost_model()
